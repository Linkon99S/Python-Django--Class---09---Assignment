from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def course(request):
    return HttpResponse('Welcome Shahadot Hossain Linkon in Django for web & AI')

def data_science(request):
    available_course={'fcourse':['Machine Learning', 'Deep Learning', 'Data Analysis', 'Big Data', 'Django', 'AWS']}
    return render(request, 'courses/datascience.html', available_course)

def machine_learning(request):
    return render(request, 'courses/machinelearning.html')

def deep_learning(request):
    return render(request, 'courses/deeplearning.html')

def big_data(request):
    return render(request, 'courses/bigdata.html')


